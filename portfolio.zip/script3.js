$(document).ready(function(){
    
  // Typing animation
  var typed = new Typed(".typing", {
      strings: ["Frontend Developer (JavaScript/ React)", "Backend Developer (PHP, Laravel)", "Designer (Figma, Canva, Adobe Illustrator)"], // , "Freelancer", "Blogger"
      typeSpeed: 70,
      backSpeed: 50,
      loop: true
  });
});